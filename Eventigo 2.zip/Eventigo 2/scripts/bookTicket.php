<?php
session_start();

if($_POST['eventId'] != null){
    $_SESSION["EventID"] = $_POST['eventId'];
  }
if($_SESSION["EventID"] == null){
    header("Location:events.php");
}

require_once "config.php";

$sql =  "SELECT eventName,totalTickets,ticketCost,ticketsSold FROM eventslist WHERE EventID = " .$_SESSION["EventID"];

$result = $link->query($sql);

if($result != Null){


  $row = $result->fetch_assoc();
    // output data of each row have a maxium number of events diplayed
  $eventName = $row['eventName'];
  $totalTickets = $row["totalTickets"];
  $ticketCost = $row['ticketCost'];
  $soldTickets = $row['ticketsSold'];

}else {
  echo "No results";
}
$remainingTickets = $totalTickets - $soldTickets;


?>



<form id="Book Ticket" name="createEvent" action="addNameToBookings.php" onsubmit="return confirm('Are you sure you want to submit?');" method="POST">
	<h2>Create Event</h2>
	<table cellpadding="5">

  <tr>
    <td>Event Name :</td>
    <td> <?php echo  $eventName; ?></td>
  </tr>
  <tr>
    <td>Ticket's Remaining:</td>
    <td> <?php echo  $remainingTickets; ?></td>
  </tr>
  <tr>
    <td>Ticket cost :</td>
    <td> £<?php echo  $ticketCost; ?></td>
  </tr>
  <tr>
    <td>Username:</td>
    <td colspan="2"><input type="text" name="username" id="txtCustomerName" /></td>
  </tr>
  <tr>
    <td>CardNumber:</td>
    <td colspan="2"><input type="text" name="CardNumber" id="txtCardNumber" value = "1234567890123456" /></td>
  </tr>

		<!--add review to review page or clear fields-->
		<tr><td>
				<input type="submit" />
				<input type="button" value="Return" onclick="location.href='events.php'" />
		</td></tr>
	</table>
</form>
