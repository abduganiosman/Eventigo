<?php

session_start();
//pulling data from event creation form
$username = $_POST['username'];
$cardNumber = $_POST['CardNumber'];


require_once "config.php";
$sql = "SELECT UserID FROM users where username =  '".$username."'";

$uresult = $link->query($sql);

//checks that the user exsists
if($uresult != Null && $uresult->num_rows != 0 ){

  $urow = $uresult->fetch_assoc();
  $userID = $urow['UserID'];
  // output data of each row have a maxium number of events diplayed
  $sql = "SELECT Balance FROM testmoneyaccounts WHERE CardNumber =".$cardNumber;
  $cresult = $link->query($sql);
  if($cresult != Null){
    $crow = $cresult->fetch_assoc();
    $cardBalance = $crow['Balance'];

    //gets info form events table required.
    $sql =  "SELECT ticketCost,ticketsSold FROM eventslist WHERE EventID = " .$_SESSION['EventID'];
    $eresult = $link->query($sql);

    if($eresult != Null){
      $erow = $eresult->fetch_assoc();
      $ticketCost = $erow['ticketCost'];
      $ticketsSold = $erow['ticketsSold'];

      if($cardBalance > $ticketCost){

        //Gets the attencances list for the event
        $fileName = "AttendanceLists/";
        $fileName .= (String) $_SESSION["EventID"].".txt";

        $myfile = fopen($fileName,"r") or die("Unable to open file!");

        //checks if the User already has a ticket for the event
        //window.location.href='events.php';
        while(!feof($myfile)) {
          if($userID == trim(fgets($myfile))){
            echo "<script>
            alert('You Already Own a ticket to this event');
            window.location.href='events.php';
            </script>";
            return;
          }
        }

        //if the user is not found in the file then the purchase will be completed and the user would have purchased a ticket
        if(feof($myfile)){
          $myfile = fopen($fileName, "a") or die("Unable to open file!");
          $data = $userID."\r\n";
          fwrite($myfile,$data);
          fclose($myfile);

          //updates the user balance deducting the cost of the ticket.
          $sql = "UPDATE testmoneyaccounts SET Balance = ". (INT) ($cardBalance - $ticketCost) . " WHERE CardNumber = ".$cardNumber;
          $link->query($sql);

          //updatesz the event list with the sold ticket
          $sql ="UPDATE eventslist SET ticketsSold = ". (INT) ($ticketsSold+1) . " WHERE EventID = ". $_SESSION['EventID'];
          $link->query($sql);

          //confermation message that ticket has been purchased
          echo "<script>
          alert('The Ticket has been purchased');
          window.location.href='events.php';
          </script>";
        }

      }

    }
  }

}else {
  echo "<script>
  alert('The User doesnt exist.');
  window.location.href='events.php';
  </script>";
}





 ?>
