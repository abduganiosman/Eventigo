<?php

	//pulling data from event creation form
	$reviewerName = $_POST['name'];
	$rating = $_POST['starRating'];
	$eventName = $_POST['email'];
	$titleOfReview = $_POST['reviewTitle'];
	$reviewMessage = $_POST['message'];
	$dateTimeOfSubmission = date("Y-m-d | H:i:s");	
	
	$data = "
		<li class='timeline-event' data-aos='fade-up' data-aos-delay='.2'>
			<label class='timeline-event-icon'></label>
			<div class='timeline-event-copy'>
				<p class='timeline-event-thumbnail'>Posted: $dateTimeOfSubmission</p>
				<h3>$titleOfReview</h3>
				<h4>By $reviewerName</h4>
				Event name: $eventName<p />
				Rating: $rating/5<br />
				Comment: $reviewMessage<p />
			</div>
		</li>
	";

	//currently appending event data to html file
	$fileName = "store_reviews.html";
	$fileContents = file_get_contents($fileName);
	file_put_contents($fileName, $data . $fileContents);

	//redirecting to a script that reads data stored in storeEvents.html
	header("Location: ../index.php");
	die;
?>