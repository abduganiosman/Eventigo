<?php
	$searchString = $_POST['keywords'];
	$filename = "events.csv";
	
	
?>