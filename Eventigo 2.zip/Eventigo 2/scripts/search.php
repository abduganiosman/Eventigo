<?php

$search = $_POST['search'];

//$sql = "SELECT * FROM events WHERE nameofevent LIKE '%".$term."%'";
//	$query = mysqli_query($conn,"SELECT * FROM `events` WHERE `nameofevent` LIKE '%$qname%'");


require_once 'config.php';



$sql = "SELECT * FROM eventslist
      WHERE eventName LIKE '%{$search}%' OR genres LIKE '%{$search}%'";

//creates query for sql to display all tables
  $result = $link->query($sql);

if($result != Null){


  if ($result->num_rows > 0) {

    //variable to display the amount of events
    $i = 0;

      // output data of each row have a maxium number of events diplayed
    while(($row = $result->fetch_assoc()) && ($i<6)) {
      //calulates the reamingin tickets
      $ticketsRemaining = $row['totalTickets'] - $row['ticketsSold'];

        if($ticketsRemaining > 0){
          //only counts events that have tickets remaining
          $i++;
          //disaplys the event
          echo
          "<p>Event Name: " . $row["eventName"]."</p>".
          "<p>Genre: " . $row["genres"]."</p>".
          "<p>Tickets Reamaining: " . $ticketsRemaining."</p>".
          "<p>Ticket Cost: " ."£". $row["ticketCost"]."</p>".
          "<p>Event Date:" . $row["eventStartDate"]."</p>".
          "<p>Event Date:" . $row["eventEndDate"]."</p>".
          "<p>startTime: " . $row["startTime"]."</p>".
          "<p>EndTime:" . $row["EndTime"]."</p>".
          "<p>location: " . $row["location"]."</p>".
          "<p>description:" . $row["description"]."</p>".
          "<p>dateCreated:" . $row["dateCreated"]."</p>".
          "</p><br />".
          "<form id=\"bookEvent\" action=\"scripts/bookTicket.php\" method=\"POST\">".
          "<input type=\"hidden\" name=\"eventId\" value=\"".$row["EventID"]."\" />".
          "<input type=\"submit\" value=\"BookTicket\"/>".
          "</form>"
        ;
      }
    }
    if($i ==0){
      //dispalys this if thre are not tickets avaliable for events in the database
      echo "No Events";
    }
  } else {
      //dispalys this if thre are not events in the database
      echo "No Events";
  }
}else {
  echo "No Events";
}

$link->close();

?>
