<?php

require_once "config.php";

$sql = "CREATE TABLE  IF NOT EXISTS eventsList(
    EventID INT(8) NOT NULL AUTO_INCREMENT,
    eventName VARCHAR(50),
    genres VARCHAR(50),
    totalTickets INT,
    ticketCost INT,
    ticketsSold INT,
    eventStartDate VARCHAR(15),
    eventEndDate varchar(15),
    startTime VARCHAR(15),
    EndTime VARCHAR(12),
    location VARCHAR(30),
    description VARCHAR(255),
    dateCreated DATE,
    PRIMARY KEY(EventID)
)";

if ($link->query($sql) === TRUE) {
    echo "Table eventsList created successfully";
} else {
    echo "Error creating table: " . $link->error;
}


$sql = "INSERT INTO `eventslist` (`eventName`, `genres`, `totalTickets`, `ticketCost`, `ticketsSold`, `eventStartDate`, `eventEndDate`, `startTime`, `EndTime`, `location`, `description`, `dateCreated`) VALUES
('First Event', 'Clubnight', 100, 50, 0, '2019-03-21', '2019-03-21', '16:00', '18:00', 'Finchley, London, United Kingd', 'Best', '2019-03-21'),
('First Great Event', 'Party', 1000, 4567, 0, '2019-03-22', '2019-03-22', '17:00', '18:00', 'Dartford, United Kingdom', 'casdcdscasc', '2019-03-22'),
('Sports Event', 'Sports', 10000, 5000, 0, '2019-03-03', '2019-03-03', '17:00', '22:00', 'Cardiff, United Kingdom', 'Best Sports Event In the World!', '2019-03-22');
";


$link->query($sql);


echo "<br>";
$sql = "CREATE TABLE IF NOT EXISTS users (
  UserID INT(10) NOT NULL AUTO_INCREMENT,
  username varchar(50),
  password varchar(100),
  firstname varchar(50),
  LastName varchar(50),
  address varchar(100),
  PRIMARY KEY(UserID)
)";

if ($link->query($sql) === TRUE) {
    echo "Table users created successfully";
} else {
    echo "Error creating table: " . $link->error;
}

echo "<br>";
$sql = "CREATE TABLE IF NOT EXISTS TestMoneyAccounts (
  CardNumber varchar(16),
  Balance INT(10),
  PRIMARY KEY(CardNumber)
)";

if ($link->query($sql) === TRUE) {
    echo "Table TestMoneyAccounts created successfully";
} else {
    echo "Error creating table: " . $link->error;
}

$sql = "INSERT INTO TestMoneyAccounts (CardNumber,Balance) VALUES (1234567890123456,999999999)";

if ($link->query($sql) === TRUE) {
    echo "Card Created";
} else {
    echo "Error creating table: " . $link->error;
}



$link->close();

		//redirecting to Login page
		header("Location: ../index.php");

?>
