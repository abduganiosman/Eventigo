<?php
		/*
		public function getFirstName() {}
		public function getLastName() {}
		public function getUserName() {}
		public function getCustomerID() {}
		public function makePayment() {}
		*/
			//pulling data from event creation form
			$nameOfEvent = $_POST['eventName'];
			$genre = $_POST['cmbGenres'];
			$totalTickets =  $_POST['totalTickets'];
			$ticketCost = $_POST['ticketCost'];
			$startDate = $_POST['eventDate'];
			$endDate = $_POST['eventEndDate'];
			$startTime = $_POST['eventStartTime'];
			$endTime = $_POST['eventEndTime'];
			$locationOfEvent = $_POST['eventLocation'];
			$eventDescription = $_POST['descriptionText'];
			$dateTimeOfCreation = date("Y-m-d H:i:s");

			//connect to database
			require_once "config.php";

			//insert into statment for table
			$sql = "INSERT INTO eventslist (
				eventName, genres,totalTickets,ticketCost,ticketsSold, eventStartDate,eventEndDate, startTime, EndTime, location, description, dateCreated)
				VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

			//prepare statment
			if($stmt = mysqli_prepare($link, $sql)){

					$soldTickets =	"0";
					// Bind variables to the prepared statement as parameters
					mysqli_stmt_bind_param($stmt, "ssssssssssss",
					$nameOfEvent,
					$genre,
					$totalTickets,
					$ticketCost,
					$soldTickets,
					$startDate,
					$endDate,
					$startTime,
					$endTime,
					$locationOfEvent,
					$eventDescription,
					$dateTimeOfCreation);


					// Attempt to execute the prepared statement
					if(mysqli_stmt_execute($stmt)){

						//Creates a file using the ID of the newlay created event to create
						//a textfile that will contain the attendant list
						$sql = "SELECT max(EventID) from eventslist";
						$creatrefilename = "../AttendanceLists/";
						if($tempID = $link->query($sql)){
							while ($row = $tempID->fetch_assoc()) {
								$creatrefilename .= (String) $row["max(EventID)"] .".txt";
							}
							fopen("$creatrefilename","w");
							fclose("$creatrefilename");
						}
							// Redirect to Events page
							header("Location: events.php");
					} else{
							echo "Something went wrong. Please try again later.";
					}
					// Close statement
					mysqli_stmt_close($stmt);
			}

    // Close connection
    mysqli_close($link);

		//redirecting to review page
		//header("Location: events.php");

?>
